package com.example.demo.bootstrap;

import com.example.demo.domain.InhousePart;
import com.example.demo.domain.OutsourcedPart;
import com.example.demo.domain.Part;
import com.example.demo.domain.Product;
import com.example.demo.repositories.InhousePartRepository;
import com.example.demo.repositories.OutsourcedPartRepository;
import com.example.demo.repositories.PartRepository;
import com.example.demo.repositories.ProductRepository;
import com.example.demo.service.OutsourcedPartService;
import com.example.demo.service.OutsourcedPartServiceImpl;
import com.example.demo.service.ProductService;
import com.example.demo.service.ProductServiceImpl;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 *
 *
 *
 *
 */
@Component
public class BootStrapData implements CommandLineRunner {

    private final ProductRepository productRepository;
    private final InhousePartRepository inhousePartRepository;
    private final OutsourcedPartRepository outsourcedPartRepository;

    public BootStrapData(PartRepository partRepository, ProductRepository productRepository, OutsourcedPartRepository outsourcedPartRepository, InhousePartRepository inhousePartRepository) {
        this.productRepository = productRepository;
        this.inhousePartRepository = inhousePartRepository;
        this.outsourcedPartRepository=outsourcedPartRepository;
    }

    @Override
    public void run(String... args) throws Exception {

    if (inhousePartRepository.count() == 0) {

        // creating object from class InHousePart
        InhousePart CPU = new InhousePart();
        // setting the value for object
        CPU.setName("AMD Ryzen 7 9800X3D");
        CPU.setInv(25);
        CPU.setMinInv(1);
        CPU.setMaxInv(50);
        CPU.setPrice(479.99);
        CPU.setId(5);
        inhousePartRepository.save(CPU);

        // creating object from class InHousePart
        InhousePart Ram = new InhousePart();
        // setting the value for object
        Ram.setName("G.Skill Trident Z5 Royal Neo DDR5 (2x16GB) 32GB");
        Ram.setInv(28);
        Ram.setMinInv(1);
        Ram.setMaxInv(50);
        Ram.setPrice(154.99);
        Ram.setId(8);
        inhousePartRepository.save(Ram);
    }

        if (outsourcedPartRepository.count() == 0){

        // creating object from class OutsourcedPart
        OutsourcedPart GPU = new OutsourcedPart();
        // setting the value for object
        GPU.setCompanyName("NVIDIA");
        GPU.setName("RTX 5070 12GB");
        GPU.setInv(20);
        GPU.setMinInv(1);
        GPU.setMaxInv(50);
        GPU.setPrice(549.99);
        GPU.setId(7);
        outsourcedPartRepository.save(GPU);

        // creating object from class OutsourcedPart
        OutsourcedPart NVMe = new OutsourcedPart();
        // setting the value for object
        NVMe.setCompanyName("Western Digital");
        NVMe.setName("2TB NVMe PCIe 4.0 Internal M.2 SSD");
        NVMe.setInv(10);
        NVMe.setMinInv(1);
        NVMe.setMaxInv(50);
        NVMe.setPrice(119.99);
        NVMe.setId(4);
        outsourcedPartRepository.save(NVMe);

        // creating object from class OutsourcedPart
        OutsourcedPart TowerCase = new OutsourcedPart();
        // setting the value for object
        TowerCase.setCompanyName("NZXT");
        TowerCase.setName("H9 Flow ATX mid-tower PC case");
        TowerCase.setInv(10);
        TowerCase.setMinInv(1);
        TowerCase.setMaxInv(50);
        TowerCase.setPrice(99.99);
        TowerCase.setId(2);
        outsourcedPartRepository.save(TowerCase);
    }
        if(productRepository.count() == 0) {
            // creating an object from the product class
            Product GamingPC = new Product(15,"Gaming PC Build", 1799.99, 3 );
            productRepository.save(GamingPC);
            // creating an object from the product class
            Product OfficePC = new Product(11,"Office Desktop", 999.99, 5 );
            productRepository.save(OfficePC);
            // creating an object from the product class
            Product studentLaptop = new Product(14,"Student Laptop", 799.99, 3 );
            productRepository.save(studentLaptop);
            // creating an object from the product class
            Product creatorPC = new Product(13,"Content Creator Desktop", 2199.99, 2 );
            productRepository.save(creatorPC);
            // creating an object from the product class
            Product budgetPC = new Product(16,"Budget Desktop", 499.99, 4 );
            productRepository.save(budgetPC);
        }
    }
}
